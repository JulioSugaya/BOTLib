/*
 * Debug.cpp
 *
 *  Created on: Jan 03, 2016
 *      Author: juliosugaya
 */

#include "Arduino.h"
#include "BOTLib.h"

//<<constructor>>
Debug::Debug(){

}

//turn the LED on
void Debug::print(uint8_t t){

}

